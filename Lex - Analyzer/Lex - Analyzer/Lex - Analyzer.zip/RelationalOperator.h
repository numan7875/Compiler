#pragma once

enum RelationalOperator {
	NE = 1,
	LE = 2,
	LT = 3,
	GE = 4,
	GT = 5,
	E = 6,
	AS = 7,
	NO = 8,
};
