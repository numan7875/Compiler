#pragma once
enum ArithmeticOperator {
	ADD = 1,
	SUB = 2,
	MUL =3,
	DIV=4,
	NAR=5
};