#pragma once
enum Keyword {
		ELSE = 1,
		IF = 2,
		WHILE =3,
		RETURN =4,
		COUT =5,
		CIN = 6,
		//Data types
		INT =7,
		CHAR = 8,
		VOID = 9,
	};